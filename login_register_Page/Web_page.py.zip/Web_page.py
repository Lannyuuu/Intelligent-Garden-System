from flask import Flask, render_template, request, redirect, url_for, session, flash, jsonify
import paho.mqtt.client as mqtt
import json
from datetime import datetime
from functools import wraps
import os
import sqlite3
from werkzeug.security import generate_password_hash, check_password_hash
import io
import base64
import matplotlib
matplotlib.use('Agg')  # 必须加，防止 Flask 环境下报错
import matplotlib.pyplot as plt
import numpy as np
from matplotlib.dates import DateFormatter

app = Flask(__name__)
app.secret_key = 'your-secret-key-here'  # 请更改为一个安全的密钥

# 用户数据文件
USERS_FILE = 'users.json'

# 确保用户数据文件存在
if not os.path.exists(USERS_FILE):
    with open(USERS_FILE, 'w') as f:
        json.dump({}, f)

def load_users():
    with open(USERS_FILE, 'r') as f:
        return json.load(f)

def save_users(users):
    with open(USERS_FILE, 'w') as f:
        json.dump(users, f)

# ========== 用户认证 ==========
def login_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'logged_in' not in session:
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    return decorated_function

# ========== MQTT Configuration ==========
BROKER = "localhost"
PORT = 1883
TOPIC = "garden/sensors"  # Must match your publisher

# ========== Sensor Data Storage ==========
sensor_data = {
    "timestamp": "Waiting for data...",
    "humidity": 0,
    "drought_alert": False,
    "light": 0,
    "ph": 0,
    "rain": False,
    "co2": 0,
    "last_update": "Never updated"
}

DB_PATH = os.path.join(os.path.dirname(__file__), '..', 'smart_garden', 'garden_sensor_data.db')

def get_latest_db_data():
    """从数据库获取最新一条传感器数据"""
    try:
        conn = sqlite3.connect(DB_PATH)
        cursor = conn.cursor()
        cursor.execute('SELECT Timestamp, Humidity, DroughtAlert, Light, PH, Rain, CO2 FROM SensorData ORDER BY ID DESC LIMIT 1')
        row = cursor.fetchone()
        conn.close()
        if row:
            # 数据库字段顺序: Timestamp, Humidity, DroughtAlert, Light, PH, Rain, CO2
            return {
                "timestamp": row[0],
                "humidity": row[1],
                "drought_alert": bool(row[2]),
                "light": row[3],
                "ph": row[4],
                "rain": bool(row[5]),
                "co2": row[6],
                "last_update": datetime.now().strftime("%H:%M:%S")
            }
    except Exception as e:
        print(f"❌ 数据库读取错误: {e}")
    return None

def get_history_data(limit=50):
    """获取最近limit条历史数据"""
    try:
        conn = sqlite3.connect(DB_PATH)
        cursor = conn.cursor()
        cursor.execute('''
            SELECT Timestamp, Humidity, DroughtAlert, Light, PH, Rain, CO2
            FROM SensorData
            ORDER BY ID DESC
            LIMIT ?
        ''', (limit,))
        rows = cursor.fetchall()
        conn.close()
        # 转换为字典列表
        history = []
        for row in rows:
            history.append({
                "timestamp": row[0],
                "humidity": row[1],
                "drought_alert": bool(row[2]),
                "light": row[3],
                "ph": row[4],
                "rain": bool(row[5]),
                "co2": row[6]
            })
        return history
    except Exception as e:
        print(f"❌ 历史数据读取错误: {e}")
    return []

# ========== 实时监测图数据缓存 ==========
plot_data_history = {
    'timestamp': [],
    'co2': [],
    'ph': [],
    'humidity': [],
    'light': []
}
PLOT_MAX_POINTS = 50

def update_plot_data(new_data):
    from datetime import datetime
    plot_data_history['timestamp'].append(datetime.now())
    if len(plot_data_history['timestamp']) > PLOT_MAX_POINTS:
        plot_data_history['timestamp'].pop(0)
    for key in ['co2', 'ph', 'humidity', 'light']:
        plot_data_history[key].append(new_data.get(key, 0))
        if len(plot_data_history[key]) > PLOT_MAX_POINTS:
            plot_data_history[key].pop(0)

# ========== MQTT Callbacks ==========
def on_connect(client, userdata, flags, rc, properties=None):
    if rc == 0:
        print("✅ Successfully connected to MQTT broker!")
        client.subscribe(TOPIC)
    else:
        print(f"❌ Connection failed with code: {rc}")


def on_message(client, userdata, msg):
    global sensor_data
    try:
        data = json.loads(msg.payload.decode())

        # Convert timestamp to local time
        utc_time = datetime.fromisoformat(data["timestamp"])
        local_time = utc_time.astimezone().strftime("%Y-%m-%d %H:%M:%S")

        # Update all sensor data
        sensor_data.update({
            "timestamp": local_time,
            "humidity": data["humidity"],
            "drought_alert": data["drought_alert"],
            "light": data["light"],
            "ph": data["ph"],
            "rain": data["rain"],
            "co2": data["co2"],
            "last_update": datetime.now().strftime("%H:%M:%S")
        })
        # 新增：更新绘图数据
        update_plot_data(data)  # 新增：每次收到数据都更新缓存
        print(f"Data received: {sensor_data}")

    except Exception as e:
        print(f"❌ Data processing error: {e}")


# ========== MQTT Client Setup ==========
mqtt_client = mqtt.Client(mqtt.CallbackAPIVersion.VERSION2)
mqtt_client.on_connect = on_connect
mqtt_client.on_message = on_message

try:
    mqtt_client.connect(BROKER, PORT, 60)
    mqtt_client.loop_start()
except Exception as e:
    print(f"⚠️ MQTT connection error: {e}")


# ========== Flask Routes ==========
@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        confirm_password = request.form['confirm_password']

        users = load_users()
        
        # 验证用户名是否已存在
        if username in users:
            return render_template('register.html', error='Username already exists')

        # 验证密码
        if password != confirm_password:
            return render_template('register.html', error='Passwords do not match')

        # 创建新用户
        users[username] = generate_password_hash(password)
        save_users(users)

        flash('Registration successful! Please login')
        return redirect(url_for('login'))

    return render_template('register.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    error = None
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        
        users = load_users()
        if username in users and check_password_hash(users[username], password):
            session['logged_in'] = True
            session['username'] = username
            return redirect(url_for('index'))
        else:
            error = 'Invalid username or password'
    return render_template('login.html', error=error)

@app.route('/logout')
def logout():
    session.pop('logged_in', None)
    session.pop('username', None)
    return redirect(url_for('login'))

@app.route('/')
@login_required
def index():
    db_data = get_latest_db_data()
    # 优先用数据库数据，没有则用MQTT收到的
    data = db_data if db_data else sensor_data
    return render_template('index.html', data=data)

@app.route('/api/history')
@login_required
def api_history():
    # 返回最近50条历史数据，最新的在前
    history = get_history_data(limit=50)
    return jsonify(history)

# ========== 实时监测图接口 ==========
@app.route('/plot.png')
@login_required
def plot_png():
    # 直接从数据库获取最近50条数据
    history = get_history_data(limit=50)
    if not history:
        plt.figure(figsize=(12, 8))
        plt.text(0.5, 0.5, 'No Data', ha='center', va='center', fontsize=20)
        buf = io.BytesIO()
        plt.savefig(buf, format='png')
        plt.close()
        buf.seek(0)
        return app.response_class(buf.getvalue(), mimetype='image/png')

    # 按时间升序排列
    history = list(reversed(history))
    ts = [datetime.fromisoformat(row['timestamp']) for row in history]
    co2 = [row['co2'] for row in history]
    ph = [row['ph'] for row in history]
    humidity = [row['humidity'] for row in history]
    light = [row['light'] for row in history]

    THRESHOLDS = {
        'co2': {'low': 800, 'high': 1500},
        'ph': {'low': 6.0, 'high': 7.0},
        'humidity': {'low': 30, 'high': 80},
        'light': {'low': 500, 'high': 2000}
    }

    plt.figure(figsize=(12, 8))
    # --- CO2 ---
    plt.subplot(2, 2, 1)
    plt.plot(ts, co2, 'b-', linewidth=2, label='CO2 Level')
    plt.axhline(y=THRESHOLDS['co2']['low'], color='y', linestyle='--', label='Low Threshold')
    plt.axhline(y=THRESHOLDS['co2']['high'], color='r', linestyle='--', label='High Threshold')
    for i, val in enumerate(co2):
        if val < THRESHOLDS['co2']['low']:
            plt.scatter(ts[i], val, color='yellow', s=60, zorder=5)
        elif val > THRESHOLDS['co2']['high']:
            plt.scatter(ts[i], val, color='red', s=60, zorder=5)
    plt.title('CO2 Concentration Monitoring')
    plt.ylabel('CO2 (ppm)')
    plt.ylim(500, 2000)
    plt.grid(True, alpha=0.3)
    plt.legend()

    # --- pH ---
    plt.subplot(2, 2, 2)
    plt.plot(ts, ph, 'g-', linewidth=2, label='pH Level')
    plt.axhline(y=THRESHOLDS['ph']['low'], color='r', linestyle='--', label='Low Threshold')
    plt.axhline(y=THRESHOLDS['ph']['high'], color='y', linestyle='--', label='High Threshold')
    for i, val in enumerate(ph):
        if val < THRESHOLDS['ph']['low']:
            plt.scatter(ts[i], val, color='red', s=60, zorder=5)
        elif val > THRESHOLDS['ph']['high']:
            plt.scatter(ts[i], val, color='yellow', s=60, zorder=5)
    plt.title('pH Level Monitoring')
    plt.ylabel('pH Value')
    plt.ylim(4, 10)
    plt.grid(True, alpha=0.3)
    plt.legend()

    # --- Humidity ---
    plt.subplot(2, 2, 3)
    plt.plot(ts, humidity, 'm-', linewidth=2, label='Humidity')
    plt.axhline(y=THRESHOLDS['humidity']['low'], color='r', linestyle='--', label='Low Threshold')
    plt.axhline(y=THRESHOLDS['humidity']['high'], color='r', linestyle='--', label='High Threshold')
    plt.title('Humidity Monitoring')
    plt.ylabel('Humidity (%)')
    plt.ylim(0, 100)
    plt.grid(True, alpha=0.3)
    plt.legend()

    # --- Light ---
    plt.subplot(2, 2, 4)
    plt.plot(ts, light, color='orange', linewidth=2, label='Light Level')
    plt.axhline(y=THRESHOLDS['light']['low'], color='r', linestyle='--', label='Low Threshold')
    plt.title('Light Level Monitoring')
    plt.ylabel('Light (lux)')
    plt.ylim(0, 3000)
    plt.grid(True, alpha=0.3)
    plt.legend()

    # 格式化x轴
    date_form = DateFormatter("%H:%M:%S")
    for i in range(1, 5):
        plt.subplot(2, 2, i)
        plt.gca().xaxis.set_major_formatter(date_form)
        plt.gca().tick_params(axis='x', rotation=45)
    plt.tight_layout()
    buf = io.BytesIO()
    plt.savefig(buf, format='png')
    plt.close()
    buf.seek(0)
    return app.response_class(buf.getvalue(), mimetype='image/png')

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5005, debug=True)
